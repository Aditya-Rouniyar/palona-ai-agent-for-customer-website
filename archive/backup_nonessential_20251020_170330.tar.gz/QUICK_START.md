# 🚀 Quick Start Guide

## 30-Second Setup

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the agent
python main.py

# 3. Open browser
# http://localhost:5000
```

That's it! 🎉

---

## Or Use the Quick Start Script

```bash
./run.sh
```

---

## Test It Works

```bash
python test_agent.py
```

---

## Example Queries to Try

In the chat interface, type:

1. **General**: `What can you do?`
2. **Product Search**: `Recommend me a t-shirt for sports`
3. **Price Filter**: `Show me products under $50`
4. **Category**: `What electronics do you have?`

In the Image Search tab:
- Upload any product image
- See matching products

---

## Files You Need

✅ `main.py` - The AI agent  
✅ `product_catalog.json` - Product database  
✅ `requirements.txt` - Dependencies  

Everything else is documentation!

---

## API Key (Optional)

The code includes a default key. For production:

```bash
export GEMINI_API_KEY="your-key-here"
```

---

## Troubleshooting

**Issue**: Module not found  
**Fix**: `pip install -r requirements.txt`

**Issue**: Port in use  
**Fix**: Change port in `main.py` line 650

**Issue**: Import errors  
**Fix**: Run `python test_agent.py` to diagnose

---

## Documentation

- **README.md** - Full documentation
- **EXAMPLES.md** - Usage examples
- **SUBMISSION.md** - Project summary

---

## Features

✅ Chat with AI shopping assistant  
✅ Get product recommendations  
✅ Search by image  
✅ Filter by price  
✅ Browse categories  

---

## Architecture

```
User → Web UI → Flask API → AI Agent → Tools → Product Catalog
                              ↓
                         Gemini 2.0 Flash
```

---

## Need Help?

1. Read the error message
2. Check README.md
3. Run test_agent.py
4. Review code comments in main.py

---

**That's all you need to know! Start chatting!** 🛍️

