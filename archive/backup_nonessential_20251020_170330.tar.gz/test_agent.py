#!/usr/bin/env python3
"""Test the agent to ensure it uses tools correctly."""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import commerce_agent, search_products_by_text

# Test the tool directly
print("Testing search_products_by_text tool directly:")
print("-" * 50)
result = search_products_by_text("running shoes")
print(result[:500] + "..." if len(result) > 500 else result)
print("\n")

# Test the agent
print("Testing agent with product query:")
print("-" * 50)
response = commerce_agent.invoke({
    "input": "search for running shoes", 
    "chat_history": []
})
print("Agent response:")
print(response['output'][:500] + "..." if len(response['output']) > 500 else response['output'])