# Commerce AI Agent - Usage Examples

This document provides example interactions with the AI agent to demonstrate all three required features.

---

## 🎯 Feature 1: General Conversation

### Example 1: Introduction
```
User: "What's your name?"

Agent: "Hi! I'm Rufus, your intelligent shopping assistant. 
        I'm here to help you find the perfect products for your needs!"
```

### Example 2: Capabilities
```
User: "What can you do?"

Agent: "I can help you with:
        1. Product recommendations based on your needs
        2. Searching for specific items in our catalog
        3. Finding products by uploading an image
        4. Filtering products by price range
        5. Browsing by category
        
        Just tell me what you're looking for!"
```

### Example 3: Help
```
User: "How does this work?"

Agent: "It's simple! Just tell me what you're looking for or what you need. 
        For example:
        - 'I need running shoes'
        - 'Show me wireless headphones under $100'
        - 'Recommend a sports t-shirt'
        
        I'll search our catalog and find the best options for you. 
        You can also upload an image if you have a picture of what you want!"
```

---

## 🎯 Feature 2: Text-Based Product Recommendation

### Example 1: Sports Apparel
```
User: "Recommend me a t-shirt for sports"

Agent: "Found 3 product(s):

**Nike Dri-FIT Sports T-Shirt**
- Price: $29.99
- Category: Sports Apparel
- Description: Lightweight, breathable sports t-shirt with moisture-wicking 
  technology. Perfect for running, gym workouts, and outdoor activities.
- Features: Moisture-wicking, Breathable fabric, Athletic fit, Quick-dry
- Available Colors: Black, Navy, Red, White
- Available Sizes: S, M, L, XL, XXL

This t-shirt would be perfect for your sports activities! The moisture-wicking 
technology keeps you dry, and it's available in multiple colors and sizes."
```

### Example 2: Running Shoes
```
User: "I need running shoes for marathon training"

Agent: "Found 1 product(s):

**Adidas Performance Running Shoes**
- Price: $89.99
- Category: Sports Footwear
- Description: Premium running shoes with responsive cushioning and breathable 
  mesh upper. Designed for comfort during long-distance runs.
- Features: Responsive cushioning, Breathable mesh, Durable outsole, Lightweight
- Available Colors: Black/White, Blue/Orange, Gray/Red
- Available Sizes: 7, 8, 9, 10, 11, 12

These are excellent for marathon training! The responsive cushioning will 
protect your joints during long runs, and the breathable mesh keeps your 
feet comfortable."
```

### Example 3: Price-Based Search
```
User: "Show me products under $50"

Agent: "Found 8 product(s) in the range $0.00 - $50.00:
- Nike Dri-FIT Sports T-Shirt: $29.99
- Under Armour Compression Shorts: $34.99
- Reebok CrossFit Training Gloves: $24.99
- Puma Sports Backpack: $49.99
- Hydro Flask Water Bottle 32oz: $44.95

Would you like more details about any of these products?"
```

### Example 4: Electronics
```
User: "What wireless headphones do you have?"

Agent: "Found 1 product(s):

**Sony Wireless Headphones WH-1000XM5**
- Price: $399.99
- Category: Electronics
- Description: Premium noise-cancelling wireless headphones with exceptional 
  sound quality and 30-hour battery life.
- Features: Active noise cancellation, 30-hour battery, Premium sound, Wireless
- Available Colors: Black, Silver
- Available Sizes: One Size

These are top-of-the-line headphones! The active noise cancellation is 
excellent for travel or focus, and the 30-hour battery means you rarely 
need to charge them."
```

### Example 5: Category Browse
```
User: "What categories do you have?"

Agent: "Available categories:
- Sports Apparel
- Sports Footwear
- Sports Equipment
- Sports Accessories
- Outdoor Apparel
- Electronics
- Home Appliances
- Casual Apparel

Which category interests you?"
```

### Example 6: Specific Product
```
User: "Tell me about the Apple Watch"

Agent: "**Apple Watch Series 9**
- Price: $429.99
- Category: Electronics
- Description: Advanced smartwatch with fitness tracking, health monitoring, 
  and seamless iOS integration.
- Features: Fitness tracking, Heart rate monitor, GPS, Water-resistant
- Available Colors: Midnight, Starlight, Silver
- Available Sizes: 41mm, 45mm

The Apple Watch Series 9 is perfect for fitness enthusiasts! It tracks your 
workouts, monitors your heart rate, has built-in GPS for running, and is 
water-resistant. Plus, it integrates seamlessly with your iPhone."
```

### Example 7: Yoga Equipment
```
User: "I'm starting yoga, what do you recommend?"

Agent: "Found 1 product(s):

**Lululemon Yoga Mat**
- Price: $78.00
- Category: Sports Equipment
- Description: Premium reversible yoga mat with excellent grip and cushioning. 
  Perfect for yoga, pilates, and floor exercises.
- Features: Reversible, Non-slip grip, 5mm thickness, Antimicrobial
- Available Colors: Purple/Pink, Black/Gray, Blue/Green
- Available Sizes: One Size

This is an excellent choice for beginners! The 5mm thickness provides great 
cushioning for your joints, and the non-slip grip keeps you stable during poses. 
The antimicrobial feature keeps it fresh between uses."
```

### Example 8: Home Appliances
```
User: "I need a vacuum cleaner"

Agent: "Found 1 product(s):

**Dyson V11 Vacuum Cleaner**
- Price: $599.99
- Category: Home Appliances
- Description: Powerful cordless vacuum with intelligent cleaning modes and 
  up to 60 minutes of runtime.
- Features: Cordless, Intelligent modes, 60-min runtime, HEPA filtration
- Available Colors: Blue/Silver
- Available Sizes: One Size

The Dyson V11 is a premium choice! Being cordless gives you freedom to clean 
anywhere, and the 60-minute runtime is enough for most homes. The HEPA 
filtration is great if you have allergies."
```

---

## 🎯 Feature 3: Image-Based Product Search

### How to Use Image Search:

1. **Open the web interface** at `http://localhost:5000`
2. **Click the "📸 Image Search" tab**
3. **Upload an image** of a product (e.g., a sports shoe, headphones, etc.)
4. **Wait for analysis** (3-5 seconds)
5. **View results** with matching products

### What Happens:

```
Step 1: User uploads image of running shoes

Step 2: AI analyzes image
"The image shows athletic running shoes with a mesh upper and cushioned sole.
They appear to be sports footwear designed for running or training, featuring
modern design elements with breathable material."

Step 3: Results shown
Found 1 matching product(s):

**Adidas Performance Running Shoes**
- Price: $89.99
- Category: Sports Footwear
- Description: Premium running shoes with responsive cushioning...
```

### Supported Image Types:
- JPEG/JPG
- PNG
- GIF
- WebP

### Tips for Best Results:
- Use clear, well-lit images
- Center the product in the frame
- Avoid cluttered backgrounds
- Use product-focused images (not lifestyle shots)

---

## 🔄 Conversation Flow Examples

### Multi-Turn Conversation

```
User: "Hi"
Agent: "Hello! How can I help you today?"

User: "I'm looking for workout clothes"
Agent: "Great! I can help with that. Are you looking for:
        - Tops (t-shirts, tank tops)?
        - Bottoms (shorts, leggings)?
        - Accessories (bags, gloves)?
        Or would you like to see all workout apparel?"

User: "Show me tops"
Agent: "Found 2 product(s):
        
        **Nike Dri-FIT Sports T-Shirt** - $29.99
        Lightweight, breathable sports t-shirt with moisture-wicking...
        
        Would you like more details about either of these?"

User: "Tell me more about the Nike shirt"
Agent: "**Nike Dri-FIT Sports T-Shirt**
        - Price: $29.99
        - Features: Moisture-wicking, Breathable fabric, Athletic fit
        - Available in: Black, Navy, Red, White
        - Sizes: S, M, L, XL, XXL
        
        This is perfect for any workout! Would you like to know about anything else?"
```

---

## 💡 Pro Tips

### For Best Recommendations:

1. **Be Specific**: "sports t-shirt" is better than "shirt"
2. **Mention Use Case**: "for marathon training" helps narrow options
3. **State Preferences**: "wireless headphones under $100"
4. **Ask Questions**: "What's good for beginners?"

### For Price Filtering:

```
- "Show me products under $50"
- "What do you have between $20 and $100?"
- "Recommend something affordable"
```

### For Categories:

```
- "Show me all electronics"
- "What sports equipment do you have?"
- "Browse home appliances"
```

---

## 🧪 Testing the Agent

### Quick Test Script:

```bash
# Start the agent
python main.py

# In another terminal, test the API:
curl -X POST http://localhost:5000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "What can you do?", "session_id": "test-123"}'
```

### Or use the test script:

```bash
python test_agent.py
```

---

## 📊 Expected Behavior

### ✅ Agent Should:
- Respond within 1-3 seconds for text queries
- Maintain conversation context
- Use tools appropriately (search, filter, etc.)
- Provide detailed product information
- Be friendly and helpful

### ❌ Agent Should NOT:
- Recommend products not in catalog
- Provide incorrect prices
- Lose conversation context
- Take more than 5 seconds to respond
- Give generic responses without using tools

---

## 🎓 Understanding Agent Decisions

The agent uses **tool calling** to decide which function to use:

```
User Query → Agent Reasoning → Tool Selection → Response

Example:
"sports t-shirt" → [Needs product search] → search_products_by_text()
"under $50" → [Needs price filter] → filter_products_by_price()
"what can you do?" → [General conversation] → No tool needed
```

---

## 🌟 Advanced Examples

### Combining Multiple Criteria:

```
User: "I need waterproof gear for hiking under $200"

Agent: [Searches for "waterproof hiking gear", filters by price]

"Found 1 product(s):

**The North Face Hiking Jacket**
- Price: $159.99
- Description: Waterproof, breathable hiking jacket with adjustable hood
- Features: Waterproof, Breathable, Adjustable hood, Multiple pockets

Perfect for hiking! It's waterproof, breathable, and well within your budget."
```

### Follow-up Questions:

```
User: "Do you have any fitness trackers?"
Agent: [Shows Apple Watch]

User: "Is there something cheaper?"
Agent: [Could filter by lower price or suggest alternatives]
```

---

## ✨ Try These Queries

Copy and paste these into the chat to test all features:

1. `What's your name?`
2. `Recommend me a t-shirt for sports`
3. `Show me electronics under $500`
4. `I need yoga equipment`
5. `What categories do you have?`
6. `Tell me about the Sony headphones`
7. `I'm training for a marathon, what do I need?`
8. `Show me all home appliances`
9. `What's good for CrossFit training?`
10. `Do you have any smartwatches?`

---

## 📝 Notes

- All responses use **actual products** from the catalog
- The agent **autonomously decides** which tools to use
- **Conversation history** is maintained per session
- **Image search** uses multimodal AI for analysis
- The agent is **production-ready** with error handling

---

Enjoy using the Commerce AI Agent! 🎉

