# Perplexity Integration for Real-Time Product Search 🛍️

## Overview

Your Palona AI Agent now uses **Perplexity Search API** to find REAL products from actual online stores instead of using a local catalog. This provides:

- ✅ **Real-time product availability**
- ✅ **Current prices from online retailers**
- ✅ **Direct shopping links to buy products**
- ✅ **Actual product images from stores**
- ✅ **Up-to-date product information**

## What Changed

### 1. **Text-Based Search** 
- Now searches real online stores via Perplexity API
- Returns actual products with live prices and shopping links
- Shows source information (which online store)
- Includes "View on Store" buttons

### 2. **Image-Based Search**
- Analyzes uploaded images using AI
- Searches for similar products online
- Returns real products you can buy
- Direct links to online stores

### 3. **Price Range Search**
- Finds real products within your budget
- Current prices from online retailers
- Direct shopping links

## How to Set Up Perplexity

1. **Get your Perplexity API Key**:
   - Go to https://www.perplexity.ai/settings/api
   - Sign up/login and generate an API key

2. **Set the API Key**:
   ```bash
   export PERPLEXITY_API_KEY="your-perplexity-api-key-here"
   ```

3. **Start the Server**:
   ```bash
   cd /Users/adityarouniyar/Desktop/palona
   python3 main.py
   ```

4. **Access at**: http://localhost:3000

## Example Queries

Try these in the chat:
- "Show me laptops under $1000"
- "I need running shoes"
- "Find me a good coffee maker"
- "Show me gaming headsets"
- "Products between $50 and $100"

## How It Works

1. **User Query** → Agent receives your request
2. **Perplexity Search** → Searches real online stores
3. **Product Cards** → Returns formatted results with:
   - Product images
   - Current prices
   - Store links
   - Descriptions
   - "View on Store" buttons

## Fallback Behavior

If Perplexity API is not available:
- Falls back to local product catalog
- Still shows product cards with images
- Limited to sample products

## Benefits

- **Always Current**: Real-time prices and availability
- **Real Products**: Actual items you can buy now
- **Direct Links**: Click to go straight to the store
- **Better Variety**: Access to millions of products
- **Price Comparison**: See products from multiple stores

## Important Notes

1. **API Usage**: Each search uses your Perplexity API quota
2. **Response Time**: May be slightly slower than local search (but worth it!)
3. **Internet Required**: Needs active internet connection
4. **Real Links**: All product links go to actual online stores

## Troubleshooting

**No results showing?**
- Check if PERPLEXITY_API_KEY is set correctly
- Verify internet connection
- Check API quota on Perplexity dashboard

**Falling back to local catalog?**
- This happens when Perplexity API key is not set
- Set the key and restart the server

**Want to see what's happening?**
- Check the terminal where you're running `python3 main.py`
- Look for "Perplexity search error" messages

## Try It Now!

Your shopping assistant is ready to find real products online. Just ask for what you need, and it will search actual stores for you! 🎉
